import sqlite3
from contextlib import contextmanager
from datetime import datetime

from paths import DB_PATH

DB_NAME = DB_PATH  # kept for old imports


def validate_progress(value):
    if value is None:
        return
    if isinstance(value, bool):
        raise ValueError("Progress must be a number.")
    try:
        v = float(value)
    except (TypeError, ValueError):
        raise ValueError("Progress must be a number.")
    if v < 0 or v > 100:
        raise ValueError("Progress must be between 0 and 100.")


def validate_date(value, field_name="Date"):
    if value is None or value == "":
        return
    try:
        datetime.strptime(str(value)[:10], "%Y-%m-%d")
    except (ValueError, TypeError):
        raise ValueError(f"{field_name} must be a valid date (YYYY-MM-DD).")


def get_connection():
    connection = sqlite3.connect(DB_PATH, timeout=30.0)
    connection.execute("PRAGMA foreign_keys = ON")
    connection.execute("PRAGMA busy_timeout = 30000")
    return connection


@contextmanager
def connect():
    """
    with connect() as connection:
        ...

    Commits on success, rolls back on error and ALWAYS closes.
    """

    connection = get_connection()

    try:
        yield connection
        connection.commit()

    except Exception:
        connection.rollback()
        raise

    finally:
        connection.close()
