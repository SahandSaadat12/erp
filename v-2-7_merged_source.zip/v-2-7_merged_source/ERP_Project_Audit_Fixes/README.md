# ERP Project Management — audit-fix working copy

Python 3.12 + CustomTkinter + SQLite desktop application.

## Important deployment limits

- This build is intended for **one desktop / one active user at a time**.
- Do not place `erp.db` on a network share and do not use it for simultaneous multi-computer access. A server/API and per-session identity design are required for that.
- This is project/cost tracking software, not a full accounting, tax, payroll, or invoicing system.
- The shipped `dist/main.exe` from the uploaded archive was intentionally excluded. Its build did not match the source tree. Build a fresh executable from this source and verify it on clean Windows.
- The current GitHub license gate is a basic sharing deterrent, not strong tamper-resistant licensing. The embedded HMAC key and publicly visible hashes must not be described as secure licensing or machine binding. The license design should be reviewed before commercial release.

## First run

Install dependencies and run:

```powershell
py -m pip install -r requirements.txt
py main.py
```

On a genuinely empty database, the login window asks you to create the first administrator. Use a unique username and a password of at least 12 characters. There are no default administrator credentials in this clean source package.

**Do not run demo-seeding or password-reset scripts against a customer database.** They were intentionally excluded from this package.

## Database and backup

The database is stored next to source code when running from source, and under `%APPDATA%\ERP-ProjectManagement` when running as a frozen executable.

- Settings provides database backup and restore controls.
- Backups are checked with SQLite `integrity_check` and `foreign_key_check`.
- Restore creates a safety backup of the current database first. Close other ERP instances, restore, then restart the application.
- Keep at least one backup on a different physical device or secure storage location. A backup on the same disk does not protect against disk failure.
- Existing databases should be backed up before testing this code. Never test restore/migration against your only copy.

## Financial calculation rules in this working copy

- Expense amounts must be numeric, finite, and non-negative; known expense statuses are `Pending`, `Paid`, and `Cancelled`.
- Cost summaries include `Pending` and `Paid` expenses and exclude `Cancelled` expenses. Confirm this rule matches your business definition before using reports for decisions.
- Project `expected_price` is a planned/expected project value, not collected revenue. The app does not yet provide a proper invoice/payment ledger.

## Build

On Windows, in a clean virtual environment:

```powershell
py -m pip install -r requirements.txt pyinstaller
py -m PyInstaller --noconfirm --clean main.spec
```

The expected output is `dist\main.exe`. Test startup, first-run administrator creation, license activation, icons/themes, backup, restore, and an upgrade from a copy of the previous database before distributing it.

## Tests

Run:

```powershell
py -m unittest discover -v
```

The tests in this copy target the current source design. Older tests for an absent Ed25519 licensing implementation were removed because they could not run against the actual `licensing/` source in the uploaded archive. This does **not** mean the licensing system has passed a security audit.

## Remaining work before commercial delivery

- Test the GUI and executable on clean Windows.
- Reconcile the real licensing design; local state can be forged and licenses are not machine-bound.
- Audit all edit/add forms and all sensitive database operations for permission enforcement and input validation.
- Verify all calculations and reports with realistic non-sensitive sample data.
- Add/verify user-specific audit attribution, role-change refresh, lockout persistence, and restore/migration scenarios.
- Do not claim multi-user support, full accounting, or strong license protection.
