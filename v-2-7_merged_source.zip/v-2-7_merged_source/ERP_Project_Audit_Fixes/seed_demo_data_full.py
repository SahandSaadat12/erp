#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Generate a second, expanded batch of clearly labelled synthetic demo data for the ERP SQLite database.

Default volume: 50 clients, 50 projects, 50 contracts, 250 expenses,
250 tasks, 50 text documents, 50 demo users, 8 demo roles, 50 demo phases, and 8 demo departments. This script never deletes existing data.
It refuses to run if DEMO2-* project codes already exist, to prevent duplicates.

Run from the project folder:
    python seed_demo_data.py
Or target a specific existing database:
    python seed_demo_data.py --db "C:\\path\\to\\erp.db"

The application should be CLOSED before running this script.
"""
from __future__ import annotations

import argparse
import random
import shutil
import sqlite3
import sys
from datetime import date, timedelta, datetime
from pathlib import Path

DEFAULTS = {
    "clients": 50,
    "projects": 50,
    "contracts": 50,
    "expenses": 250,
    "tasks_per_project": 5,
    "documents": 50,
    "users": 50,
    "roles": 8,
    "phases": 50,
    "departments": 8,
}

PROJECT_TYPES = ["Fabrication", "Production", "Installation", "Maintenance", "Engineering", "Repair"]
PROJECT_STATUSES = ["Open", "In Progress", "On Hold", "Completed", "Cancelled", "Closed"]
PRIORITIES = ["Low", "Medium", "High", "Critical"]
CONTRACT_STATUSES = ["Active", "Completed", "Canceled"]
EXPENSE_STATUSES = ["Paid", "Paid", "Paid", "Pending", "Pending", "Cancelled"]
EXPENSE_CATEGORIES = ["Materials", "Transport", "Equipment", "Salary", "Office", "Software", "Other"]
PHASE_STATUSES = ["Pending", "In Progress", "Completed", "Skipped", "Cancelled"]
TASK_STATUSES = ["Pending", "In Progress", "Completed", "Blocked"]

CLIENT_NAMES = [
    "Atlas Industrial Group", "Pars Engineering Demo", "BluePeak Manufacturing",
    "Arman Infrastructure", "Nova Energy Systems", "Mehr Construction Group",
    "Caspian Mechanical", "Rayan Industrial Services", "Aftab Steel Works",
    "Paya Equipment Co.", "Dena Project Partners", "Kavir Technical Group",
    "Saba Production House", "Zagros Engineering", "Shayan Facility Services",
    "Tavan Process Systems", "Orchid Industrial Demo", "Faraz Installation Group",
    "Negin Technical Services", "Arian Maintenance Co.", "Delta Project Studio",
    "Mehrgan Manufacturing", "Soroush Engineering Demo", "Avand Infrastructure",
    "Roshd Industrial Solutions", "Kian Project Services", "Baran Mechanical Group",
    "Azin Production Systems", "Tirgan Equipment Demo", "Sepand Engineering",
]
PROJECT_NAMES = [
    "Factory Line Upgrade", "Warehouse Expansion", "Boiler Maintenance", "Production Hall Fit-out",
    "Water Treatment Installation", "Workshop Modernization", "Packaging Line Project",
    "Industrial Ventilation", "Control Panel Replacement", "Steel Structure Fabrication",
    "Pump Station Upgrade", "Power Distribution Renewal", "Compressed Air Network",
    "Cooling System Retrofit", "Loading Bay Construction", "Safety System Upgrade",
    "CNC Workshop Setup", "Pipe Rack Fabrication", "Office Building Renovation",
    "Conveyor System Installation", "Generator Room Upgrade", "Fire Protection Retrofit",
    "Material Handling Improvement", "Quality Lab Setup", "Industrial Roof Repair",
    "Production Capacity Expansion", "Equipment Relocation", "Utility Network Renewal",
    "Maintenance Planning Rollout", "Assembly Area Redesign",
]
TASK_TITLES = [
    "Review technical drawings", "Confirm material quantities", "Prepare work area",
    "Complete procurement request", "Inspect incoming materials", "Perform installation",
    "Run quality inspection", "Resolve punch-list items", "Prepare progress report",
    "Obtain client approval", "Update project schedule", "Complete handover documents",
]


def hash_demo_password(password: str) -> str:
    """Match the project's security.py scrypt password format."""
    import base64, hashlib, os
    salt = os.urandom(16)
    digest = hashlib.scrypt(password.encode("utf-8"), salt=salt, n=2 ** 14, r=8, p=1)
    return "scrypt$" + base64.b64encode(salt).decode() + "$" + base64.b64encode(digest).decode()


def iso(day: date) -> str:
    return day.isoformat()


def require_schema(connection: sqlite3.Connection) -> None:
    required = {
        "clients", "departments", "phases", "projects", "project_phases",
        "contracts", "expenses", "tasks", "documents", "users", "roles",
        "role_permissions", "settings", "lookups", "history",
    }
    existing = {
        row[0] for row in connection.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()
    }
    missing = sorted(required - existing)
    if missing:
        raise RuntimeError(
            "The selected file does not look like an initialized ERP database. "
            "Missing tables: " + ", ".join(missing) + ". Open the ERP once first, "
            "or select the correct erp.db with --db."
        )


def create_verified_backup(db_path: Path) -> Path:
    backup_dir = db_path.parent / "demo_seed_backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    backup_path = backup_dir / f"erp_before_demo_seed_{stamp}.db"
    source = sqlite3.connect(str(db_path))
    destination = sqlite3.connect(str(backup_path))
    try:
        source.backup(destination)
        destination.commit()
        result = destination.execute("PRAGMA integrity_check").fetchone()
        fk_errors = destination.execute("PRAGMA foreign_key_check").fetchall()
        if not result or result[0] != "ok" or fk_errors:
            raise RuntimeError(
                f"Backup verification failed: integrity={result!r}, foreign_keys={fk_errors[:5]!r}"
            )
    except Exception:
        destination.close()
        source.close()
        backup_path.unlink(missing_ok=True)
        raise
    finally:
        try:
            destination.close()
        except Exception:
            pass
        try:
            source.close()
        except Exception:
            pass
    return backup_path


def insert_demo_data(db_path: Path, args: argparse.Namespace) -> dict[str, int | str]:
    rng = random.Random(args.seed)
    today = date.today()
    demo_doc_dir = db_path.parent / "demo_documents"
    created_files: list[Path] = []
    backup_path: Path | None = None

    # Refuse to write to a missing file: this avoids accidentally creating a new,
    # empty database because the user chose the wrong working directory.
    if not db_path.is_file():
        raise FileNotFoundError(
            f"Database not found: {db_path}\n"
            "Open the ERP first, then run this script with the correct database path."
        )

    connection = sqlite3.connect(str(db_path), timeout=15)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    try:
        require_schema(connection)
        existing_demo = connection.execute(
            "SELECT COUNT(*) FROM projects WHERE project_code LIKE 'DEMO2-%'"
        ).fetchone()[0]
        if existing_demo:
            raise RuntimeError(
                f"Found {existing_demo} DEMO2-* projects already. Nothing was changed, "
                "to avoid duplicate sample data. Use a fresh copy of the database "
                "or remove demo data manually after backing up."
            )

        phases = connection.execute(
            "SELECT id, phase_name FROM phases WHERE COALESCE(is_active, 1) = 1 ORDER BY id"
        ).fetchall()
        if len(phases) < 5:
            # Seed named demo phases only when the database has too few active phases.
            names = [
                "DEMO - Planning", "DEMO - Procurement", "DEMO - Production",
                "DEMO - Quality Check", "DEMO - Handover",
            ]
            for name in names:
                connection.execute(
                    "INSERT OR IGNORE INTO phases(phase_name, is_active) VALUES(?, 1)", (name,)
                )
            phases = connection.execute(
                "SELECT id, phase_name FROM phases WHERE COALESCE(is_active, 1) = 1 ORDER BY id"
            ).fetchall()
        departments = connection.execute(
            "SELECT id, department_name FROM departments ORDER BY id"
        ).fetchall()
        users = connection.execute(
            "SELECT id FROM users WHERE COALESCE(status, 'Active') = 'Active' ORDER BY id"
        ).fetchall()

        # The backup is created before any insert. It is stored separately from the DB.
        backup_path = create_verified_backup(db_path)
        connection.execute("BEGIN IMMEDIATE")

        # Add clearly named demo departments and phases inside the transaction.
        department_names = [
            "Demo Engineering", "Demo Production", "Demo Quality", "Demo Finance",
            "Demo Procurement", "Demo Sales", "Demo Operations", "Demo IT",
        ]
        for i in range(args.departments):
            connection.execute(
                "INSERT OR IGNORE INTO departments(department_name) VALUES(?)",
                (f"[DEMO2] {department_names[i % len(department_names)]} {i + 1:02d}",),
            )
        phase_names = [
            "Planning", "Requirements", "Design", "Engineering", "Procurement",
            "Material Inspection", "Fabrication", "Assembly", "Installation", "Testing",
            "Quality Control", "Safety Review", "Documentation", "Client Review",
            "Commissioning", "Training", "Handover", "Closeout", "Maintenance Setup",
            "Final Inspection",
        ]
        for i in range(args.phases):
            connection.execute(
                "INSERT OR IGNORE INTO phases(phase_name, is_active) VALUES(?, 1)",
                (f"[DEMO2] {phase_names[i % len(phase_names)]} {i + 1:02d}",),
            )
        phases = connection.execute(
            "SELECT id, phase_name FROM phases WHERE COALESCE(is_active, 1) = 1 ORDER BY id"
        ).fetchall()
        departments = connection.execute(
            "SELECT id, department_name FROM departments ORDER BY id"
        ).fetchall()

        # Eight roles with deliberately different permission sets.
        all_permissions = [
            "projects.view", "projects.create", "projects.edit", "projects.delete", "projects.restore",
            "contracts.view", "contracts.create", "contracts.edit", "contracts.delete", "contracts.restore",
            "expenses.view", "expenses.create", "expenses.edit", "expenses.delete", "expenses.restore",
            "documents.view", "documents.create", "documents.edit", "documents.delete", "documents.restore",
            "roadmap.view", "roadmap.edit", "clients.view", "clients.manage", "users.manage", "roles.manage",
            "settings.view", "settings.manage", "history.view", "history.clear", "archive.view",
            "archive.restore", "archive.permanent_delete", "backup.create",
        ]
        role_templates = [
            ("Demo Manager", all_permissions),
            ("Demo Project Lead", ["projects.view", "projects.create", "projects.edit", "contracts.view", "contracts.create", "contracts.edit", "expenses.view", "expenses.create", "expenses.edit", "documents.view", "documents.create", "documents.edit", "roadmap.view", "roadmap.edit", "clients.view", "history.view", "archive.view"]),
            ("Demo Finance", ["projects.view", "contracts.view", "contracts.create", "contracts.edit", "expenses.view", "expenses.create", "expenses.edit", "expenses.delete", "clients.view", "history.view", "backup.create"]),
            ("Demo Engineer", ["projects.view", "projects.edit", "documents.view", "documents.create", "documents.edit", "roadmap.view", "roadmap.edit", "clients.view"]),
            ("Demo QC", ["projects.view", "documents.view", "documents.create", "roadmap.view", "clients.view"]),
            ("Demo Document Controller", ["projects.view", "contracts.view", "documents.view", "documents.create", "documents.edit", "documents.delete", "history.view"]),
            ("Demo Viewer", ["projects.view", "contracts.view", "expenses.view", "documents.view", "roadmap.view", "clients.view", "settings.view", "history.view", "archive.view"]),
            ("Demo Guest", []),
        ]
        selected_roles = role_templates[:max(1, min(args.roles, len(role_templates)))]
        role_ids = []
        for role_name, permissions in selected_roles:
            final_role_name = "[DEMO2] " + role_name
            connection.execute(
                "INSERT OR IGNORE INTO roles(name, is_system) VALUES(?, 0)", (final_role_name,)
            )
            role_id = connection.execute(
                "SELECT id FROM roles WHERE name = ? COLLATE NOCASE", (final_role_name,)
            ).fetchone()[0]
            for permission in permissions:
                connection.execute(
                    "INSERT OR IGNORE INTO role_permissions(role_id, permission) VALUES(?, ?)",
                    (role_id, permission),
                )
            role_ids.append((final_role_name, role_id))

        # Demo accounts use a documented shared password; statuses vary on purpose.
        demo_password_hash = hash_demo_password("DemoOnly-2026!")
        for i in range(args.users):
            role_name, _ = role_ids[i % len(role_ids)]
            user_status = "Active" if i % 10 < 7 else ("Inactive" if i % 10 < 9 else "Disabled")
            username = f"demo2_user_{i + 1:03d}"
            connection.execute(
                "INSERT OR IGNORE INTO users(full_name, username, password, role, status) VALUES(?, ?, ?, ?, ?)",
                (f"[DEMO2] User {i + 1:03d}", username, demo_password_hash, role_name, user_status),
            )
        users = connection.execute(
            "SELECT id FROM users WHERE COALESCE(status, 'Active') = 'Active' ORDER BY id"
        ).fetchall()

        # Populate the actual lookup categories with the app's known values.
        lookup_values = {
            "project_status": ["Open", "In Progress", "On Hold", "Completed", "Cancelled", "Closed"],
            "project_type": ["Fabrication", "Production", "Installation", "Maintenance", "Repair", "Engineering", "Other"],
            "priority": ["Low", "Medium", "High", "Critical"],
            "phase_status": ["Pending", "In Progress", "Completed", "Skipped", "Cancelled"],
            "contract_status": ["Active", "Completed", "Canceled"],
            "expense_status": ["Pending", "Paid", "Cancelled"],
            "expense_category": ["Materials", "Transport", "Equipment", "Salary", "Office", "Software", "Other"],
            "document_type": ["Contract", "Invoice", "Report", "Other"],
        }
        for category, values in lookup_values.items():
            for index, value in enumerate(values, 1):
                connection.execute(
                    "INSERT OR IGNORE INTO lookups(category, value, sort_order, is_system, is_active) VALUES(?, ?, ?, 0, 1)",
                    (category, value, index),
                )

        # Add sample settings and history without overwriting real settings.
        for key, value in [
            ("demo2_mode", "true"), ("demo2_dataset", "Expanded demo batch"),
            ("demo2_user_count", str(args.users)), ("demo2_project_count", str(args.projects)),
        ]:
            connection.execute(
                "INSERT OR IGNORE INTO settings(setting_key, setting_value) VALUES(?, ?)",
                (key, value),
            )
        for i in range(50):
            connection.execute(
                "INSERT INTO history(action, entity, entity_id, label, old_data, new_data, performed_by_user_id, performed_by_username) VALUES(?, ?, NULL, ?, NULL, ?, NULL, ?)",
                ("DEMO2_SAMPLE", ["projects", "contracts", "expenses", "users", "roles"][i % 5],
                 f"[DEMO2] Sample history event {i + 1:03d}", "{\"demo\": true}", "demo2_seed_script"),
            )

        client_ids: list[int] = []
        for i in range(args.clients):
            company = f"[DEMO2] {CLIENT_NAMES[i % len(CLIENT_NAMES)]} {i + 1:02d}"
            cursor = connection.execute(
                """INSERT INTO clients(company_name, contact_person, phone, email, address, description)
                   VALUES(?, ?, ?, ?, ?, ?)""",
                (
                    company,
                    f"Demo Contact {i + 1:02d}",
                    f"0900000{i + 1:04d}",
                    f"demo.client{i + 1:02d}@example.invalid",
                    f"Demo Industrial Zone, Block {i % 8 + 1}",
                    "Synthetic test record generated by seed_demo_data.py; not a real customer.",
                ),
            )
            client_ids.append(cursor.lastrowid)

        project_ids: list[int] = []
        project_phase_ids: dict[int, list[int]] = {}
        project_prices: dict[int, float] = {}
        for i in range(args.projects):
            client_id = client_ids[i % len(client_ids)]
            start = today - timedelta(days=rng.randint(15, 500))
            duration = rng.randint(45, 240)
            end = start + timedelta(days=duration)
            status = PROJECT_STATUSES[i % len(PROJECT_STATUSES)]
            if status == "Completed":
                progress = 100.0
            elif status in ("Cancelled", "Closed"):
                progress = float(rng.choice([0, 25, 50, 75, 100]))
            elif status == "Open":
                progress = float(rng.choice([0, 5, 10, 15]))
            else:
                progress = float(rng.randrange(10, 96, 5))
            expected_price = float(rng.randrange(800_000_000, 8_000_000_000, 50_000_000))
            department_id = departments[i % len(departments)]["id"] if departments else None
            manager_id = users[i % len(users)]["id"] if users else None
            project_name = f"[DEMO2] {PROJECT_NAMES[i % len(PROJECT_NAMES)]} {i + 1:02d}"
            cursor = connection.execute(
                """INSERT INTO projects(
                    project_code, project_name, client_id, project_type, department_id, manager_id,
                    start_date, end_date, progress, priority, current_phase_id, project_status,
                    description, created_at, updated_at, expected_price
                ) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    f"DEMO2-{i + 1:03d}", project_name, client_id,
                    PROJECT_TYPES[i % len(PROJECT_TYPES)], department_id, manager_id,
                    iso(start), iso(end), progress, PRIORITIES[i % len(PRIORITIES)],
                    phases[min((i % len(phases)), len(phases) - 1)]["id"], status,
                    "Synthetic demo project. All amounts and parties are fictional.",
                    iso(today), iso(today), expected_price,
                ),
            )
            project_id = cursor.lastrowid
            project_ids.append(project_id)
            project_prices[project_id] = expected_price

            # Five phase entries with weights totaling exactly 100.
            chosen_phases = [phases[(i + j) % len(phases)] for j in range(5)]
            weights = [20.0, 20.0, 20.0, 20.0, 20.0]
            phase_progresses = [
                min(100.0, max(0.0, progress - 20 * (4 - j))) for j in range(5)
            ]
            project_phase_ids[project_id] = []
            for j, phase in enumerate(chosen_phases):
                phase_status = (
                    "Completed" if phase_progresses[j] >= 100 else
                    "In Progress" if phase_progresses[j] > 0 else "Pending"
                )
                phase_start = start + timedelta(days=duration * j // 5)
                phase_end = start + timedelta(days=duration * (j + 1) // 5)
                phase_cursor = connection.execute(
                    """INSERT INTO project_phases(
                        project_id, phase_id, percentage, progress, status, sort_order,
                        start_date, end_date, expected_price
                    ) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        project_id, phase["id"], weights[j], phase_progresses[j], phase_status,
                        j + 1, iso(phase_start), iso(phase_end), expected_price / 5,
                    ),
                )
                project_phase_ids[project_id].append(phase_cursor.lastrowid)

        # One contract per generated project (or as many as requested).
        for i in range(args.contracts):
            project_id = project_ids[i % len(project_ids)]
            client_id = client_ids[i % len(client_ids)]
            value = project_prices[project_id]
            paid_ratio = rng.choice([0.0, 0.2, 0.35, 0.5, 0.75, 1.0])
            status = CONTRACT_STATUSES[i % len(CONTRACT_STATUSES)]
            connection.execute(
                """INSERT INTO contracts(
                    project_id, client_id, contract_name, contract_number, contract_value,
                    paid_amount, contract_date, payment_terms, status, description
                ) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    project_id, client_id, f"[DEMO2] Contract {i + 1:03d}",
                    f"DEMO2-CON-{i + 1:03d}", value, round(value * paid_ratio, 2),
                    iso(today - timedelta(days=rng.randint(5, 360))),
                    rng.choice(["Net 15", "Net 30", "Milestone-based", "30% advance, balance on completion"]),
                    status,
                    "Synthetic contract for UI/report testing; not legally valid.",
                ),
            )

        for i in range(args.expenses):
            project_id = project_ids[i % len(project_ids)]
            phase_ids = project_phase_ids[project_id]
            category = EXPENSE_CATEGORIES[i % len(EXPENSE_CATEGORIES)]
            amount = float(rng.randrange(250_000, 120_000_000, 50_000))
            status = EXPENSE_STATUSES[i % len(EXPENSE_STATUSES)]
            expense_date = today - timedelta(days=rng.randint(0, 500))
            title = f"[DEMO2] {category} expense {i + 1:03d}"
            connection.execute(
                """INSERT INTO expenses(
                    project_id, project_phase_id, title, category, amount, expense_date,
                    description, paid_by, status
                ) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    project_id, phase_ids[i % len(phase_ids)], title, category, amount,
                    iso(expense_date),
                    "Synthetic test expense. Do not use for real accounting.",
                    f"Demo Employee {(i % 12) + 1:02d}", status,
                ),
            )

        for i, project_id in enumerate(project_ids):
            for j in range(args.tasks_per_project):
                start = today - timedelta(days=rng.randint(0, 120))
                due = start + timedelta(days=rng.randint(3, 45))
                task_status = TASK_STATUSES[(i + j) % len(TASK_STATUSES)]
                task_progress = 100 if task_status == "Completed" else rng.choice([0, 10, 25, 50, 75])
                connection.execute(
                    """INSERT INTO tasks(
                        project_id, title, description, assigned_to, start_date, due_date,
                        progress, priority, status
                    ) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        project_id,
                        f"[DEMO2] {TASK_TITLES[(i + j) % len(TASK_TITLES)]} #{j + 1}",
                        "Synthetic task generated for testing filters, status badges, and project details.",
                        f"Demo Employee {(i + j) % 12 + 1:02d}", iso(start), iso(due),
                        task_progress, PRIORITIES[(i + j) % len(PRIORITIES)], task_status,
                    ),
                )

        # Generate real, harmless text files so the Documents page does not point
        # to fake/nonexistent paths. They are clearly labelled as test documents.
        demo_doc_dir.mkdir(parents=True, exist_ok=True)
        for i in range(args.documents):
            project_id = project_ids[i % len(project_ids)]
            doc_type = ["Report", "Contract", "Invoice", "Other"][i % 4]
            doc_path = demo_doc_dir / f"DEMO2-DOC-{i + 1:03d}.txt"
            content = (
                "ERP DEMO DOCUMENT — SYNTHETIC TEST DATA\n"
                f"Document number: DEMO-DOC-{i + 1:03d}\n"
                f"Project ID: {project_id}\n"
                f"Document type: {doc_type}\n"
                "This file is fictional and is not a real contract, invoice, or report.\n"
            )
            doc_path.write_text(content, encoding="utf-8")
            created_files.append(doc_path)
            connection.execute(
                """INSERT INTO documents(
                    project_id, title, file_path, document_type, upload_date, description
                ) VALUES(?, ?, ?, ?, ?, ?)""",
                (
                    project_id, f"[DEMO2] {doc_type} {i + 1:03d}", str(doc_path),
                    doc_type, iso(today - timedelta(days=rng.randint(0, 300))),
                    "Synthetic test document; not a real business record.",
                ),
            )

        # Sanity checks before committing.
        foreign_key_errors = connection.execute("PRAGMA foreign_key_check").fetchall()
        if foreign_key_errors:
            raise RuntimeError(f"Foreign-key check failed: {foreign_key_errors[:5]!r}")
        bad_weights = connection.execute(
            """SELECT project_id, SUM(percentage) AS total
               FROM project_phases WHERE project_id IN (
                   SELECT id FROM projects WHERE project_code LIKE 'DEMO2-%'
               ) GROUP BY project_id HAVING ABS(total - 100.0) > 0.001"""
        ).fetchall()
        if bad_weights:
            raise RuntimeError(f"Project phase weights do not sum to 100: {bad_weights[:5]!r}")

        connection.commit()
        return {
            "database": str(db_path),
            "backup": str(backup_path),
            "clients": args.clients,
            "projects": args.projects,
            "contracts": args.contracts,
            "expenses": args.expenses,
            "tasks": args.projects * args.tasks_per_project,
            "documents": args.documents,
            "documents_folder": str(demo_doc_dir),
            "users": args.users, "roles": len(selected_roles), "phases": args.phases,
            "departments": args.departments, "history_rows": 50,
        }
    except Exception:
        try:
            connection.rollback()
        except Exception:
            pass
        for file_path in created_files:
            try:
                file_path.unlink(missing_ok=True)
            except OSError:
                pass
        raise
    finally:
        connection.close()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Add synthetic DEMO data to an existing ERP SQLite database."
    )
    parser.add_argument("--db", type=Path, help="Path to an existing erp.db. Defaults to the app's DB_PATH.")
    parser.add_argument("--clients", type=int, default=DEFAULTS["clients"])
    parser.add_argument("--projects", type=int, default=DEFAULTS["projects"])
    parser.add_argument("--contracts", type=int, default=DEFAULTS["contracts"])
    parser.add_argument("--expenses", type=int, default=DEFAULTS["expenses"])
    parser.add_argument("--tasks-per-project", type=int, default=DEFAULTS["tasks_per_project"])
    parser.add_argument("--documents", type=int, default=DEFAULTS["documents"])
    parser.add_argument("--users", type=int, default=DEFAULTS["users"])
    parser.add_argument("--roles", type=int, default=DEFAULTS["roles"])
    parser.add_argument("--phases", type=int, default=DEFAULTS["phases"])
    parser.add_argument("--departments", type=int, default=DEFAULTS["departments"])
    parser.add_argument("--seed", type=int, default=20261009, help="Random seed for repeatable demo data.")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    for name in ("clients", "projects", "contracts", "expenses", "tasks_per_project", "documents", "users", "roles", "phases", "departments"):
        value = getattr(args, name)
        if value < 0:
            print(f"ERROR: --{name.replace('_', '-')} cannot be negative.", file=sys.stderr)
            return 2
    if args.projects < 1:
        print("ERROR: --projects must be at least 1.", file=sys.stderr)
        return 2
    if args.clients < 1:
        print("ERROR: --clients must be at least 1 when generating projects.", file=sys.stderr)
        return 2

    if args.db:
        db_path = args.db.expanduser().resolve()
    else:
        try:
            from paths import DB_PATH
            db_path = Path(DB_PATH).resolve()
        except Exception as error:
            print(f"ERROR: Could not determine DB_PATH: {error}", file=sys.stderr)
            return 2

    print("\nERP DEMO DATA GENERATOR")
    print("-----------------------")
    print(f"Database: {db_path}")
    print(f"Will add: {args.clients} clients, {args.projects} projects, {args.contracts} contracts,")
    print(f"          {args.expenses} expenses, {args.projects * args.tasks_per_project} tasks, {args.documents} documents,")
    print(f"          {args.users} users, up to {args.roles} roles, {args.phases} phases, {args.departments} departments, and 50 history rows.")
    print("All generated rows will be labelled [DEMO2] / DEMO2-* and use fictional data.")
    print("Demo login password for created accounts: DemoOnly-2026! (change/delete these accounts after testing).")
    print("The script will NOT delete existing data. A verified backup is created first.")
    print("Close the ERP application before continuing.\n")
    answer = input("Type ADD DEMO DATA to continue: ").strip()
    if answer != "ADD DEMO DATA":
        print("Cancelled. No data was added.")
        return 0

    try:
        result = insert_demo_data(db_path, args)
    except Exception as error:
        print(f"\nERROR: {error}", file=sys.stderr)
        return 1

    print("\nSUCCESS — demo data inserted.")
    for key, value in result.items():
        print(f"{key}: {value}")
    print("\nOpen the ERP and inspect Dashboard, Projects, Roadmap, Contracts, Expenses, Documents, and Archive/history.")
    print("To return to the pre-seed state, use the verified backup path above via Restore while the ERP is closed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
