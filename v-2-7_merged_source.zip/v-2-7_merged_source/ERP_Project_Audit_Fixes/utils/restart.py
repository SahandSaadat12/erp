import os
import subprocess
import sys


def restart_app():
    """Start a fresh copy of the application and close this one."""

    if getattr(sys, "frozen", False):
        command = [sys.executable]
    else:
        command = [sys.executable] + sys.argv

    subprocess.Popen(command)

    os._exit(0)
