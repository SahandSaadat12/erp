@echo off
setlocal
REM Build from the single maintained PyInstaller spec.
REM Output: dist\main.exe
REM User data is stored under %APPDATA%\ERP-ProjectManagement when frozen.

py -m pip install -r requirements.txt pyinstaller
if errorlevel 1 goto :error
py -m PyInstaller --noconfirm --clean main.spec
if errorlevel 1 goto :error

echo.
echo Build finished: dist\main.exe
echo Test this executable on a clean Windows machine before distribution.
pause
exit /b 0

:error
echo Build failed. Review the error output above.
pause
exit /b 1
