import sqlite3
from contextlib import contextmanager

from paths import DB_PATH

DB_NAME = DB_PATH  # kept for old imports


def get_connection():
    connection = sqlite3.connect(DB_PATH)
    connection.execute("PRAGMA foreign_keys = ON")
    return connection


@contextmanager
def connect():
    """
    with connect() as connection:
        ...

    Commits on success, rolls back on error and ALWAYS closes.
    """

    connection = get_connection()

    try:
        yield connection
        connection.commit()

    except Exception:
        connection.rollback()
        raise

    finally:
        connection.close()
