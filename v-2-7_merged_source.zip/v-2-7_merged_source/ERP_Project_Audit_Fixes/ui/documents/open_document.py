import os
import subprocess
import sys
from tkinter import messagebox

from db.documents import get_document


# files that may be opened from inside the app
# (never launch .exe / .bat / .ps1 ... straight from a database value)
ALLOWED_EXTENSIONS = {
    ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".xlsm", ".csv",
    ".ppt", ".pptx", ".txt", ".rtf", ".odt", ".ods",
    ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp", ".tif", ".tiff",
    ".dwg", ".dxf", ".step", ".stp", ".igs", ".iges",
    ".zip", ".rar", ".7z",
}

FILE_PATH_INDEX = 3      # get_document() -> id, project_id, title, file_path, ...


def open_document(document_id):

    try:

        document = get_document(document_id)

        if not document:

            messagebox.showerror(
                "Open Document",
                "Document not found."
            )

            return

        file_path = document[FILE_PATH_INDEX]

        if not file_path:

            messagebox.showwarning(
                "Open Document",
                "This document does not have a file."
            )

            return

        if not os.path.isfile(file_path):

            messagebox.showerror(
                "Open Document",
                f"File not found:\n\n{file_path}\n\n"
                "It may have been moved, renamed or deleted."
            )

            return

        extension = os.path.splitext(file_path)[1].lower()

        if extension not in ALLOWED_EXTENSIONS:

            messagebox.showwarning(
                "Open Document",
                f"Files of type '{extension or 'unknown'}' "
                "cannot be opened from here.\n\n"
                "Open the file manually from its folder."
            )

            return

        if sys.platform.startswith("win"):
            os.startfile(file_path)

        elif sys.platform == "darwin":
            subprocess.Popen(["open", file_path])

        else:
            subprocess.Popen(["xdg-open", file_path])

    except Exception as error:

        messagebox.showerror(
            "Open Document",
            str(error)
        )
