import customtkinter as ctk
from tkinter import messagebox, filedialog, StringVar

from config import *
from db.lookups import get_values as get_lookup_values

from db.documents import (
    insert_document,
    get_document_projects
)

from utils.jalali_calender import open_jalali_calendar
from utils.date_converter import jalali_to_gregorian, InvalidDateError


def add_document(parent, on_saved=None):

    window = ctk.CTkToplevel(parent)

    window.title("Add Document")
    window.geometry("600x750")
    window.minsize(500, 600)

    window.transient(parent)
    window.grab_set()


    # ======================================================
    # Main Frame
    # ======================================================

    main_frame = ctk.CTkFrame(
        window,
        fg_color="transparent"
    )

    main_frame.pack(
        fill="both",
        expand=True
    )


    form = ctk.CTkScrollableFrame(
        main_frame,
        fg_color="transparent"
    )

    form.pack(
        fill="both",
        expand=True,
        padx=10,
        pady=10
    )


    # ======================================================
    # Title
    # ======================================================

    ctk.CTkLabel(
        form,
        text="Document Title",
        font=FONT_NORMAL
    ).pack(
        anchor="w",
        padx=15,
        pady=(5,5)
    )


    title_entry = ctk.CTkEntry(
        form,
        height=40,
        placeholder_text="Document name"
    )

    title_entry.pack(
        fill="x",
        padx=15,
        pady=(0,15)
    )


    # ======================================================
    # Project
    # ======================================================

    ctk.CTkLabel(
        form,
        text="Project",
        font=FONT_NORMAL
    ).pack(
        anchor="w",
        padx=15,
        pady=(5,5)
    )


    projects = get_document_projects()


    project_map = {
        name: project_id
        for project_id, name in projects
    }


    project_values = [
        "No Project"
    ] + list(project_map.keys())


    project_combo = ctk.CTkComboBox(
        form,
        values=project_values,
        height=40
    )

    project_combo.pack(
        fill="x",
        padx=15,
        pady=(0,15)
    )


    project_combo.set(
        "No Project"
    )


    # ======================================================
    # File Path
    # ======================================================

    ctk.CTkLabel(
        form,
        text="File",
        font=FONT_NORMAL
    ).pack(
        anchor="w",
        padx=15,
        pady=(5,5)
    )


    file_frame = ctk.CTkFrame(
        form,
        fg_color="transparent"
    )

    file_frame.pack(
        fill="x",
        padx=15,
        pady=(0,15)
    )


    file_entry = ctk.CTkEntry(
        file_frame,
        height=40
    )

    file_entry.pack(
        side="left",
        fill="x",
        expand=True
    )


    def browse_file():

        path = filedialog.askopenfilename()

        if path:

            file_entry.delete(
                0,
                "end"
            )

            file_entry.insert(
                0,
                path
            )


    ctk.CTkButton(
        file_frame,
        text="Browse",
        width=90,
        command=browse_file
    ).pack(
        side="right",
        padx=(10,0)
    )


    # ======================================================
    # Type
    # ======================================================

    ctk.CTkLabel(
        form,
        text="Document Type",
        font=FONT_NORMAL
    ).pack(
        anchor="w",
        padx=15,
        pady=(5,5)
    )


    type_combo = ctk.CTkComboBox(
        form,
        values=get_lookup_values("document_type"),
        height=40
    )


    type_combo.pack(
        fill="x",
        padx=15,
        pady=(0,15)
    )


    type_combo.set(
        "Other"
    )
    # ======================================================
    # Upload Date
    # ======================================================

    ctk.CTkLabel(
        form,
        text="Upload Date",
        font=FONT_NORMAL
    ).pack(
        anchor="w",
        padx=15,
        pady=(5,5)
    )


    date_variable = StringVar()


    date_frame = ctk.CTkFrame(
        form,
        fg_color="transparent"
    )

    date_frame.pack(
        fill="x",
        padx=15,
        pady=(0,15)
    )


    date_entry = ctk.CTkEntry(
        date_frame,
        height=40,
        textvariable=date_variable
    )

    date_entry.pack(
        side="left",
        fill="x",
        expand=True
    )


    calendar_button = ctk.CTkButton(
        date_frame,
        text="📅",
        width=50
    )

    calendar_button.pack(
        side="right",
        padx=(10,0)
    )

    calendar_button.configure(
        command=lambda: open_jalali_calendar(
            window,
            date_variable,
            calendar_button
        )
    )


    # ======================================================
    # Description
    # ======================================================

    ctk.CTkLabel(
        form,
        text="Description",
        font=FONT_NORMAL
    ).pack(
        anchor="w",
        padx=15,
        pady=(5,5)
    )


    description_text = ctk.CTkTextbox(
        form,
        height=120
    )

    description_text.pack(
        fill="x",
        padx=15,
        pady=(0,15)
    )


    # ======================================================
    # Save
    # ======================================================

    def save_document():


        title = title_entry.get().strip()


        if not title:

            messagebox.showerror(
                "Error",
                "Please enter document title.",
                parent=window
            )

            return



        # -------------------------------
        # Project
        # -------------------------------

        selected_project = project_combo.get()


        if selected_project == "No Project":

            project_id = None

        else:

            project_id = project_map.get(
                selected_project
            )


        # -------------------------------
        # Date
        # -------------------------------

        jalali_date = date_variable.get().strip()


        if jalali_date:

            try:

                upload_date = jalali_to_gregorian(
                    jalali_date
                )

            except InvalidDateError as error:

                messagebox.showerror(
                    "Invalid Date",
                    str(error),
                    parent=window
                )

                return

        else:

            upload_date = None



        # -------------------------------
        # Description
        # -------------------------------

        description = (
            description_text
            .get("1.0", "end-1c")
            .strip()
        )



        # -------------------------------
        # Insert
        # -------------------------------

        try:

            insert_document(

                project_id,

                title,

                file_entry.get().strip(),

                type_combo.get(),

                upload_date,

                description

            )


        except Exception as error:

            messagebox.showerror(
                "Database Error",
                str(error),
                parent=window
            )

            return



        if on_saved:

            on_saved()



        messagebox.showinfo(
            "Success",
            "Document added successfully.",
            parent=window
        )


        window.destroy()



    # ======================================================
    # Buttons
    # ======================================================

    button_frame = ctk.CTkFrame(
        main_frame,
        fg_color="transparent"
    )

    button_frame.pack(
        fill="x",
        padx=15,
        pady=15
    )


    save_button = ctk.CTkButton(
        button_frame,
        text="Save Document",
        height=42,
        command=save_document
    )

    save_button.pack(
        side="left",
        expand=True,
        fill="x",
        padx=(0,5)
    )


    cancel_button = ctk.CTkButton(
        button_frame,
        text="Cancel",
        height=42,
        fg_color="gray",
        hover_color="darkgray",
        command=window.destroy
    )

    cancel_button.pack(
        side="left",
        expand=True,
        fill="x",
        padx=(5,0)
    )


    # ======================================================
    # Shortcuts
    # ======================================================

    window.bind(
        "<Escape>",
        lambda event: window.destroy()
    )


    title_entry.focus()