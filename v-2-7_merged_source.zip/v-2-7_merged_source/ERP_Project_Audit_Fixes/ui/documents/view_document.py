import customtkinter as ctk
from tkinter import messagebox

from config import *


def view_document(tree):

    # =====================================
    # Selected Document
    # =====================================

    selected = tree.selection()

    if not selected:

        messagebox.showwarning(
            "View Document",
            "Please select a document first."
        )

        return


    values = tree.item(
        selected[0],
        "values"
    )


    document_id = values[0]
    document_name = values[1]
    category = values[2]
    project = values[3]
    owner = values[4]
    created = values[5]


    # =====================================
    # Window
    # =====================================

    window = ctk.CTkToplevel()

    window.title(
        "View Document"
    )

    window.geometry(
        "600x550"
    )

    window.resizable(
        False,
        False
    )

    window.grab_set()


    # =====================================
    # Title
    # =====================================

    ctk.CTkLabel(
        window,
        text="Document Details",
        font=FONT_TITLE,
        text_color=TEXT
    ).pack(
        anchor="w",
        padx=30,
        pady=(25,20)
    )


    # =====================================
    # Details Frame
    # =====================================

    details_frame = ctk.CTkFrame(
        window,
        fg_color=CARD,
        corner_radius=12,
        border_width=1,
        border_color=BORDER
    )


    details_frame.pack(
        fill="both",
        expand=True,
        padx=25,
        pady=(0,25)
    )


    details = [

        ("Document ID", document_id),

        ("Document Name", document_name),

        ("Category", category),

        ("Project", project),

        ("Owner", owner),

        ("Created Date", created)

    ]


    for row, (label_text, value) in enumerate(details):


        label = ctk.CTkLabel(
            details_frame,
            text=label_text,
            font=FONT_NORMAL,
            text_color=TEXT2
        )


        label.grid(
            row=row,
            column=0,
            sticky="w",
            padx=25,
            pady=12
        )


        value_label = ctk.CTkLabel(
            details_frame,
            text=value or "-",
            font=FONT_NORMAL,
            text_color=TEXT
        )


        value_label.grid(
            row=row,
            column=1,
            sticky="w",
            padx=25,
            pady=12
        )


    details_frame.grid_columnconfigure(
        1,
        weight=1
    )


    # =====================================
    # Close
    # =====================================

    ctk.CTkButton(
        details_frame,
        text="Close",
        width=120,
        command=window.destroy
    ).grid(
        row=len(details),
        column=0,
        columnspan=2,
        pady=(25,20)
    )