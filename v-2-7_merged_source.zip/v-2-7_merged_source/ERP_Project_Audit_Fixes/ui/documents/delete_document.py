from tkinter import messagebox

from database import archive_single_record


def delete_selected_document(
    tree,
    on_deleted=None
):

    # =====================================
    # Selected
    # =====================================

    selected = tree.selection()

    if not selected:

        messagebox.showwarning(
            "Delete Document",
            "Please select a document first."
        )

        return

    values = tree.item(
        selected[0],
        "values"
    )

    document_id = values[0]

    # =====================================
    # Confirm
    # =====================================

    confirm = messagebox.askyesno(
        "Delete Document",
        "Are you sure you want to delete this document?\n\n"
        "This document will be moved to Archive."
    )

    if not confirm:
        return

    # =====================================
    # Archive + Delete
    # =====================================

    try:

        archive_single_record(
            "documents",
            document_id
        )

    except Exception as error:

        messagebox.showerror(
            "Database Error",
            str(error)
        )

        return

    # =====================================
    # Refresh
    # =====================================

    if on_deleted:
        on_deleted()

    messagebox.showinfo(
        "Success",
        "Document moved to Archive successfully."
    )