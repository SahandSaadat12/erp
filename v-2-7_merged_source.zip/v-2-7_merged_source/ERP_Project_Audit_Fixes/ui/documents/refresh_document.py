from db.documents import get_documents
from utils.date_converter import gregorian_to_jalali


def refresh_documents(
    tree,
    search_entry=None,
    category_combo=None,
    project_combo=None
):

    # =====================================
    # Clear Table
    # =====================================

    for item in tree.get_children():
        tree.delete(item)


    # =====================================
    # Filters
    # =====================================

    keyword = ""

    category = "All Categories"

    project = "All Projects"


    if search_entry:
        keyword = search_entry.get().strip()


    if category_combo:
        category = category_combo.get()


    if project_combo:
        project = project_combo.get()


    # =====================================
    # Load Data
    # =====================================

    documents = get_documents(
        keyword=keyword,
        category=category,
        project=project
    )


    # =====================================
    # Insert
    # =====================================

    for document in documents:

        (
            document_id,
            project_id,
            title,
            file_path,
            document_type,
            upload_date,
            description,
            project_name
        ) = document


        display_date = upload_date or "-"


        if display_date != "-":

            try:

                display_date = gregorian_to_jalali(
                    display_date
                )

            except Exception:

                pass


        tree.insert(
            "",
            "end",
            values=(

                document_id,

                title or "-",

                document_type or "-",

                project_name or "No Project",

                "-",

                display_date

            )
        )