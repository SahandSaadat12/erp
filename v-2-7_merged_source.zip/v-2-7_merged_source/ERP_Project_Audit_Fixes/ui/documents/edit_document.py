import customtkinter as ctk
from tkinter import messagebox

from config import *
from db.lookups import get_values as get_lookup_values

from db.documents import (
    get_document,
    update_document,
    get_document_projects
)


def edit_document(
    document_id,
    on_saved=None
):

    document = get_document(
        document_id
    )

    if not document:
        messagebox.showerror(
            "Error",
            "Document not found."
        )
        return


    (
        doc_id,
        project_id,
        title,
        file_path,
        document_type,
        upload_date,
        description
    ) = document


    # =====================================
    # Window
    # =====================================

    window = ctk.CTkToplevel()

    window.title(
        "Edit Document"
    )

    window.geometry(
        "600x650"
    )

    window.grab_set()


    # =====================================
    # Form
    # =====================================

    frame = ctk.CTkScrollableFrame(
        window,
        fg_color="transparent"
    )

    frame.pack(
        fill="both",
        expand=True,
        padx=15,
        pady=15
    )


    # =====================================
    # Title
    # =====================================

    ctk.CTkLabel(
        frame,
        text="Title",
        font=FONT_NORMAL
    ).pack(
        anchor="w",
        pady=(5,5)
    )


    title_entry = ctk.CTkEntry(
        frame,
        height=40
    )

    title_entry.pack(
        fill="x",
        pady=(0,15)
    )


    title_entry.insert(
        0,
        title or ""
    )


    # =====================================
    # Project
    # =====================================

    ctk.CTkLabel(
        frame,
        text="Project",
        font=FONT_NORMAL
    ).pack(
        anchor="w",
        pady=(5,5)
    )


    projects = get_document_projects()


    project_map = {
        name: pid
        for pid, name in projects
    }


    project_values = list(
        project_map.keys()
    )


    project_combo = ctk.CTkComboBox(
        frame,
        values=project_values,
        height=40
    )


    project_combo.pack(
        fill="x",
        pady=(0,15)
    )


    current_project = None

    for pid, name in projects:
        if pid == project_id:
            current_project = name


    if current_project:
        project_combo.set(
            current_project
        )


    # =====================================
    # File Path
    # =====================================

    ctk.CTkLabel(
        frame,
        text="File Path",
        font=FONT_NORMAL
    ).pack(
        anchor="w",
        pady=(5,5)
    )


    file_entry = ctk.CTkEntry(
        frame,
        height=40
    )


    file_entry.pack(
        fill="x",
        pady=(0,15)
    )


    file_entry.insert(
        0,
        file_path or ""
    )


    # =====================================
    # Type
    # =====================================

    ctk.CTkLabel(
        frame,
        text="Document Type",
        font=FONT_NORMAL
    ).pack(
        anchor="w",
        pady=(5,5)
    )


    type_combo = ctk.CTkComboBox(
        frame,
        values=get_lookup_values("document_type"),
        height=40
    )


    type_combo.pack(
        fill="x",
        pady=(0,15)
    )


    type_combo.set(
        document_type or "Other"
    )


    # =====================================
    # Description
    # =====================================

    ctk.CTkLabel(
        frame,
        text="Description",
        font=FONT_NORMAL
    ).pack(
        anchor="w",
        pady=(5,5)
    )


    description_box = ctk.CTkTextbox(
        frame,
        height=120
    )


    description_box.pack(
        fill="x",
        pady=(0,20)
    )


    description_box.insert(
        "1.0",
        description or ""
    )


    # =====================================
    # Save
    # =====================================

    def save():


        selected_project = project_combo.get()


        new_project_id = project_map.get(
            selected_project
        )


        if not title_entry.get().strip():

            messagebox.showerror(
                "Error",
                "Title is required.",
                parent=window
            )

            return



        try:

            update_document(
                document_id=document_id,
                project_id=new_project_id,
                title=title_entry.get().strip(),
                file_path=file_entry.get().strip(),
                document_type=type_combo.get(),
                description=description_box.get(
                    "1.0",
                    "end-1c"
                ).strip()
            )


        except Exception as e:

            messagebox.showerror(
                "Database Error",
                str(e),
                parent=window
            )

            return



        if on_saved:
            on_saved()


        messagebox.showinfo(
            "Success",
            "Document updated successfully.",
            parent=window
        )


        window.destroy()



    ctk.CTkButton(
        frame,
        text="💾 Save Changes",
        height=42,
        fg_color=BLUE,
        hover_color=BLUE_HOVER,
        command=save
    ).pack(
        fill="x",
        pady=10
    )