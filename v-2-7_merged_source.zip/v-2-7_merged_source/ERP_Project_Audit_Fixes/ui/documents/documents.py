import customtkinter as ctk
from tkinter import ttk, messagebox

from config import *
from ui.common.guard import guarded, perm_state

from persiantools.jdatetime import JalaliDate

from utils.date_converter import (
    gregorian_to_jalali,
    jalali_to_gregorian
)

from db.documents import (
    get_documents,
    get_document,
    get_document_projects,
    get_document_types
)

import os

from .add_document import add_document
from .edit_document import edit_document
from .delete_document import delete_selected_document
from .view_document import view_document
from .open_document import open_document


def create_documents(documents_frame, current_user=None):

    # ==========================================================
    # Clear Page
    # ==========================================================

    for widget in documents_frame.winfo_children():
        widget.destroy()

    documents_frame.grid_columnconfigure(
        0,
        weight=1
    )

    documents_frame.grid_rowconfigure(
        3,
        weight=1
    )

    # ==========================================================
    # Title
    # ==========================================================

    title = ctk.CTkLabel(
        documents_frame,
        text="Documents",
        font=FONT_TITLE,
        text_color=TEXT
    )

    title.grid(
        row=0,
        column=0,
        sticky="w",
        padx=10,
        pady=(10, 5)
    )

    # ==========================================================
    # Filter Frame
    # ==========================================================

    filter_frame = ctk.CTkFrame(
        documents_frame,
        fg_color=HEADER,
        corner_radius=12,
        border_width=1,
        border_color=BORDER
    )

    filter_frame.grid(
        row=1,
        column=0,
        sticky="ew",
        padx=10,
        pady=(0, 10)
    )

    filter_frame.grid_columnconfigure(
        0,
        weight=1
    )

    # ==========================================================
    # Search
    # ==========================================================

    search_entry = ctk.CTkEntry(
        filter_frame,
        placeholder_text="🔍 Search Document...",
        font=FONT_NORMAL,
        height=40
    )

    search_entry.grid(
        row=0,
        column=0,
        sticky="ew",
        padx=(12, 10),
        pady=12
    )

    # ==========================================================
    # Type Filter
    # ==========================================================

    type_values = [
        "All Types"
    ]

    for item in get_document_types():

        if item[0] and item[0] not in type_values:
            type_values.append(item[0])

    type_combo = ctk.CTkComboBox(
        filter_frame,
        values=type_values,
        width=170,
        font=FONT_NORMAL
    )

    type_combo.set(
        "All Types"
    )

    type_combo.grid(
        row=0,
        column=1,
        padx=(0, 10),
        pady=12
    )

    # ==========================================================
    # Project Filter
    # ==========================================================

    project_values = [
        "All Projects"
    ]

    for project_item in get_document_projects():

        project_name = project_item[1]

        if (
            project_name
            and project_name not in project_values
        ):
            project_values.append(
                project_name
            )

    project_combo = ctk.CTkComboBox(
        filter_frame,
        values=project_values,
        width=190,
        font=FONT_NORMAL
    )

    project_combo.set(
        "All Projects"
    )

    project_combo.grid(
        row=0,
        column=2,
        padx=(0, 10),
        pady=12
    )

    # ==========================================================
    # Dynamic Years
    # ==========================================================

    all_documents_for_years = get_documents()

    jalali_years = set()

    for document in all_documents_for_years:

        upload_date = document[4]

        if not upload_date:
            continue

        try:

            jalali_date = gregorian_to_jalali(
                upload_date
            )

            year_number = int(
                jalali_date.split("/")[0]
            )

            jalali_years.add(
                year_number
            )

        except (
            ValueError,
            TypeError
        ):

            pass

    if jalali_years:

        minimum_year = min(
            jalali_years
        )

        maximum_year = max(
            jalali_years
        )

        year_values = [
            "All Years"
        ]

        for year_number in range(
            maximum_year,
            minimum_year - 1,
            -1
        ):

            year_values.append(
                str(year_number)
            )

    else:

        year_values = [
            "All Years"
        ]

    # ==========================================================
    # Year Filter
    # ==========================================================

    year_combo = ctk.CTkComboBox(
        filter_frame,
        values=year_values,
        width=125,
        font=FONT_NORMAL
    )

    year_combo.set(
        "All Years"
    )

    year_combo.grid(
        row=0,
        column=3,
        padx=(0, 8),
        pady=12
    )

    # ==========================================================
    # Period Filter
    # ==========================================================

    period_combo = ctk.CTkComboBox(
        filter_frame,
        values=[
            "All Periods",
            "First Half",
            "Second Half"
        ],
        width=135,
        font=FONT_NORMAL
    )

    period_combo.set(
        "All Periods"
    )

    period_combo.grid(
        row=0,
        column=4,
        padx=(0, 10),
        pady=12
    )

    # ==========================================================
    # Table Frame
    # ==========================================================

    table_frame = ctk.CTkFrame(
        documents_frame,
        fg_color=CARD,
        corner_radius=12,
        border_width=1,
        border_color=BORDER
    )

    table_frame.grid(
        row=3,
        column=0,
        sticky="nsew",
        padx=10,
        pady=(0, 10)
    )

    table_frame.grid_rowconfigure(
        0,
        weight=1
    )

    table_frame.grid_columnconfigure(
        0,
        weight=1
    )

    # ==========================================================
    # Treeview Style
    # ==========================================================

    style = ttk.Style()

    try:
        style.theme_use("clam")
    except Exception:
        pass

    style.configure(
        "Documents.Treeview",
        background=TREE_BACKGROUND,
        foreground=TREE_FOREGROUND,
        fieldbackground=TREE_BACKGROUND,
        rowheight=TREE_ROW_HEIGHT,
        font=TREE_FONT
    )

    style.configure(
        "Documents.Treeview.Heading",
        background=TREE_HEADER_BACKGROUND,
        foreground=TREE_HEADER_FOREGROUND,
        font=TREE_HEADER_FONT
    )

    style.map(
        "Documents.Treeview",
        background=[
            ("selected", TREE_SELECTED)
        ],
        foreground=[
            ("selected", TEXT)
        ]
    )

    # ==========================================================
    # Scrollbars
    # ==========================================================

    scroll_y = ttk.Scrollbar(
        table_frame,
        orient="vertical"
    )

    scroll_x = ttk.Scrollbar(
        table_frame,
        orient="horizontal"
    )

    # ==========================================================
    # Treeview
    # ==========================================================

    tree = ttk.Treeview(
        table_frame,
        columns=(
            "id",
            "title",
            "project",
            "type",
            "date",
            "description"
        ),
        show="headings",
        style="Documents.Treeview",
        yscrollcommand=scroll_y.set,
        xscrollcommand=scroll_x.set
    )

    scroll_y.configure(
        command=tree.yview
    )

    scroll_x.configure(
        command=tree.xview
    )

    tree.grid(
        row=0,
        column=0,
        sticky="nsew"
    )

    scroll_y.grid(
        row=0,
        column=1,
        sticky="ns"
    )

    scroll_x.grid(
        row=1,
        column=0,
        sticky="ew"
    )

    # ==========================================================
    # Headers
    # ==========================================================

    tree.heading(
        "id",
        text="No"
    )

    tree.heading(
        "title",
        text="Document"
    )

    tree.heading(
        "project",
        text="Project"
    )

    tree.heading(
        "type",
        text="Type"
    )

    tree.heading(
        "date",
        text="Created"
    )

    tree.heading(
        "description",
        text="Description"
    )

    # ==========================================================
    # Columns
    # ==========================================================

    tree.column(
        "id",
        width=70,
        anchor="center"
    )

    tree.column(
        "title",
        width=250,
        anchor="w"
    )

    tree.column(
        "project",
        width=200,
        anchor="w"
    )

    tree.column(
        "type",
        width=150,
        anchor="w"
    )

    tree.column(
        "date",
        width=130,
        anchor="center"
    )

    tree.column(
        "description",
        width=350,
        anchor="w"
    )

    # ==========================================================
    # Footer
    # ==========================================================

    footer = ctk.CTkFrame(
        documents_frame,
        fg_color="transparent"
    )

    footer.grid(
        row=4,
        column=0,
        sticky="ew",
        padx=10,
        pady=(0, 5)
    )

    count_label = ctk.CTkLabel(
        footer,
        text="Showing : 0 Documents",
        text_color=TEXT2,
        font=FONT_NORMAL
    )

    count_label.grid(
        row=0,
        column=0,
        sticky="w"
    )

    # ==========================================================
    # Load Documents
    # ==========================================================

    def load_documents():

        for item in tree.get_children():
            tree.delete(item)

        keyword = search_entry.get().strip()

        selected_project = project_combo.get()

        selected_type = type_combo.get()

        selected_year = year_combo.get()

        selected_period = period_combo.get()

        # ======================================================
        # Date Range
        # ======================================================

        date_start = None
        date_end = None

        if selected_year != "All Years":

            try:

                selected_year_number = int(
                    selected_year
                )

                # ------------------------------------------------
                # First Half
                # ------------------------------------------------

                if selected_period == "First Half":

                    jalali_start = (
                        f"{selected_year_number}/01/01"
                    )

                    jalali_end = (
                        f"{selected_year_number}/06/31"
                    )

                # ------------------------------------------------
                # Second Half
                # ------------------------------------------------

                elif selected_period == "Second Half":

                    jalali_start = (
                        f"{selected_year_number}/07/01"
                    )

                    last_day = (
                        30
                        if JalaliDate.is_leap(
                            selected_year_number
                        )
                        else 29
                    )

                    jalali_end = (
                        f"{selected_year_number}/12/{last_day}"
                    )

                # ------------------------------------------------
                # Whole Year
                # ------------------------------------------------

                else:

                    jalali_start = (
                        f"{selected_year_number}/01/01"
                    )

                    last_day = (
                        30
                        if JalaliDate.is_leap(
                            selected_year_number
                        )
                        else 29
                    )

                    jalali_end = (
                        f"{selected_year_number}/12/{last_day}"
                    )

                # ------------------------------------------------
                # Convert
                # ------------------------------------------------

                date_start = jalali_to_gregorian(
                    jalali_start
                )

                date_end = jalali_to_gregorian(
                    jalali_end
                )

            except (
                ValueError,
                TypeError
            ):

                date_start = None
                date_end = None

        # ======================================================
        # Get Documents
        # ======================================================

        try:

            documents = get_documents(
                keyword=keyword,
                project=selected_project,
                document_type=selected_type,
                date_start=date_start,
                date_end=date_end
            )

        except Exception as error:

            messagebox.showerror(
                "Database Error",
                str(error)
            )

            return

        # ======================================================
        # Insert Rows
        # ======================================================

        for document in documents:

            document_id = document[0]

            title = document[1] or "-"

            project_name = (
                document[2]
                or "No Project"
            )

            document_type = (
                document[3]
                or "-"
            )

            upload_date = (
                document[4]
                or "-"
            )

            description = (
                document[5]
                or "-"
            )

            # --------------------------------------------------
            # Convert Date
            # --------------------------------------------------

            display_date = upload_date

            if display_date != "-":

                try:

                    display_date = gregorian_to_jalali(
                        display_date
                    )

                except Exception:
                    pass

            # --------------------------------------------------
            # Insert
            # --------------------------------------------------

            tree.insert(
                "",
                "end",
                values=(
                    document_id,
                    title,
                    project_name,
                    document_type,
                    display_date,
                    description
                )
            )

        # ======================================================
        # Footer
        # ======================================================

        count_label.configure(
            text=f"Showing : {len(documents)} Documents"
        )

    # ==========================================================
    # Selected ID
    # ==========================================================

    def get_selected_id():

        selected = tree.selection()

        if not selected:
            return None

        values = tree.item(
            selected[0],
            "values"
        )

        if not values:
            return None

        return values[0]

    # ==========================================================
    # Edit
    # ==========================================================

    def edit_selected():

        document_id = get_selected_id()

        if not document_id:

            messagebox.showwarning(
                "Edit Document",
                "Please select a document first."
            )

            return

        edit_document(
            int(document_id),
            load_documents
        )

    # ==========================================================
    # Open file  (double click)
    # ==========================================================

    def open_selected_document():

        document_id = get_selected_id()

        if not document_id:

            messagebox.showwarning(
                "Open Document",
                "Please select a document first."
            )

            return

        open_document(int(document_id))

    # ==========================================================
    # Clear Filters
    # ==========================================================

    def clear_filters():

        search_entry.delete(
            0,
            "end"
        )

        type_combo.set(
            "All Types"
        )

        project_combo.set(
            "All Projects"
        )

        year_combo.set(
            "All Years"
        )

        period_combo.set(
            "All Periods"
        )

        load_documents()

    # ==========================================================
    # Toolbar
    # ==========================================================

    toolbar = ctk.CTkFrame(
        documents_frame,
        fg_color="transparent"
    )

    toolbar.grid(
        row=2,
        column=0,
        sticky="w",
        padx=10,
        pady=(0, 10)
    )

    # ==========================================================
    # Add
    # ==========================================================

    add_button = ctk.CTkButton(
        toolbar,
        text="➕ Add",
        state=perm_state(current_user, "documents.create"),
        width=120,
        height=38,
        font=FONT_NORMAL,
        fg_color=GREEN,
        hover_color=GREEN_HOVER,
        command=guarded(current_user, "documents.create", "add documents", lambda: add_document(
            documents_frame,
            load_documents
        ))
    )

    add_button.grid(
        row=0,
        column=0,
        padx=(0, 8)
    )

    # ==========================================================
    # Edit
    # ==========================================================

    edit_button = ctk.CTkButton(
        toolbar,
        text="✏ Edit",
        state=perm_state(current_user, "documents.edit"),
        width=120,
        height=38,
        font=FONT_NORMAL,
        fg_color=BLUE,
        hover_color=BLUE_HOVER,
        command=guarded(current_user, "documents.edit", "edit documents", edit_selected)
    )

    edit_button.grid(
        row=0,
        column=1,
        padx=(0, 8)
    )

    # ==========================================================
    # Delete
    # ==========================================================

    delete_button = ctk.CTkButton(
        toolbar,
        text="🗑 Delete",
        state=perm_state(current_user, "documents.delete"),
        width=120,
        height=38,
        font=FONT_NORMAL,
        fg_color=DELETE,
        hover_color=DELETE_HOVER,
        command=guarded(current_user, "documents.delete", "delete documents", lambda: delete_selected_document(
            tree,
            load_documents
        ))
    )

    delete_button.grid(
        row=0,
        column=2,
        padx=(0, 8)
    )

    # ==========================================================
    # View
    # ==========================================================

    view_button = ctk.CTkButton(
        toolbar,
        text="👁 View",
        state=perm_state(current_user, "documents.view"),
        width=120,
        height=38,
        font=FONT_NORMAL,
        fg_color=VIEW,
        hover_color=VIEW_HOVER,
        command=guarded(current_user, "documents.view", "view documents", lambda: view_document(
            tree
        ))
    )

    view_button.grid(
        row=0,
        column=3,
        padx=(0, 8)
    )

    # ==========================================================
    # Refresh
    # ==========================================================

    refresh_button = ctk.CTkButton(
        toolbar,
        text="🔄 Refresh",
        width=120,
        height=38,
        font=FONT_NORMAL,
        command=load_documents
    )

    refresh_button.grid(
        row=0,
        column=4,
        padx=(0, 8)
    )

    # ==========================================================
    # Clear
    # ==========================================================

    clear_button = ctk.CTkButton(
        filter_frame,
        text="✕ Clear",
        width=90,
        height=40,
        font=FONT_NORMAL,
        fg_color=VIEW,
        hover_color=VIEW_HOVER,
        command=clear_filters
    )

    clear_button.grid(
        row=0,
        column=5,
        padx=(0, 12),
        pady=12
    )

    # ==========================================================
    # Double Click
    # ==========================================================

    tree.bind(
        "<Double-1>",
        lambda event: open_selected_document()
    )

    # ==========================================================
    # Search Events
    # ==========================================================

    search_entry.bind(
        "<KeyRelease>",
        lambda event: load_documents()
    )

    type_combo.configure(
        command=lambda value: load_documents()
    )

    project_combo.configure(
        command=lambda value: load_documents()
    )

    year_combo.configure(
        command=lambda value: load_documents()
    )

    period_combo.configure(
        command=lambda value: load_documents()
    )

    # ==========================================================
    # First Load
    # ==========================================================

    load_documents()