# -*- mode: python ; coding: utf-8 -*-
# Reproducible single-file build. Build and smoke-test on Windows before release.
from PyInstaller.utils.hooks import collect_all

ctk_datas, ctk_binaries, ctk_hiddenimports = collect_all("customtkinter")
persian_datas, persian_binaries, persian_hiddenimports = collect_all("persiantools")

app_datas = ctk_datas + persian_datas + [("icons", "icons")]
app_binaries = ctk_binaries + persian_binaries
app_hiddenimports = ctk_hiddenimports + persian_hiddenimports

a = Analysis(
    ["main.py"],
    pathex=["."],
    binaries=app_binaries,
    datas=app_datas,
    hiddenimports=app_hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)
exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name="main",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
