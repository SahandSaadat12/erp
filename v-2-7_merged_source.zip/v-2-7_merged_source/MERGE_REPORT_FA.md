# گزارش ادغام v2.5 و v2.6 ← v2.7

پایه: v2.5 (opencode). از v2.6 فقط بخش‌های سالم برداشته شد.

## از v2.6 گرفته شد
- `db/login_throttle.py` + جدول `login_attempts` (schema v5): شمارنده‌ی تلاش ناموفق ورود در دیتابیس و به‌ازای هر نام‌کاربری
- `db/users.py::upgrade_legacy_password`: ارتقای رمز plain-text قدیمی به scrypt پس از ورود موفق
- `db/dashboard.py`: قوانین داشبورد (قراردادهای لغوشده از جمع فعال خارج و جدا گزارش می‌شوند؛ پیشرفت کل = میانگین مساوی پروژه‌های غیرلغو)
- `ui/login.py`: فقط بخش throttle و ارتقای رمز
- `db/documents.py`: چک مجوز `documents.edit` در `update_document` (در v2.5 نبود) با حفظ try/finally
- تست‌های جدید: `test_throttle_and_dashboard.py`, `test_hardening.py`

## از v2.6 گرفته نشد (و دلیل)
- رمزنگاری دیتابیس (`db/encryption.py`, `encrypt_db_utility.py`, تغییرات `connection.py`/`main.py`/ورود): پیاده‌سازی ناقص است (جزئیات در پاسخ چت)
- حذف‌های v2.6 که در v2.5 درست بودند: اعتبارسنجی تاریخ، چک مجوز در phases، اعتبارسنجی فایل SQLite در backup، نوشتن اتمیک license_state، 13 تست حذف‌شده، try/finally در documents

## نتیجه تست (روی نسخه ادغام‌شده)
95 تست اجرا شد: 94 موفق، 1 خطا به‌خاطر نبودن tkinter در محیط من (`test_document_open_validates_extension`). باید روی ویندوز خودتان اجرا شود.
رابط گرافیکی (CustomTkinter) اجرا نشد؛ ورود/قفل/داشبورد فقط از طریق تست‌های واحد بررسی شده‌اند.
